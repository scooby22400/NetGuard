package eu.faircode.netguard;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

@GlideModule
public final class GlideHelper extends AppGlideModule {
}