#!/bin/sh
#apt-get install meld
meld app/src/main/res/xml-v14/preferences.xml app/src/main/res/xml-v21/preferences.xml &
